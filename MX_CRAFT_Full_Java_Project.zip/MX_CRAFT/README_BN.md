# MX CRAFT — Android Java / LibGDX

এটি একটি **3D voxel sandbox starter prototype**, Minecraft-এর পূর্ণ বিকল্প নয়।

## কী আছে
- 3D block world ও procedural ছোট terrain
- Grass, dirt, stone, wood, leaves, sand
- Camera look (স্ক্রিনের ডান পাশে drag)
- সাধারণ touch movement zones
- Break / Place action
- Creative / Survival mode toggle
- GitHub Actions দিয়ে online APK build workflow

## কী এখনো নেই
Survival mode-এর hunger/health/crafting/inventory, world save/load, mobs, multiplayer, chunk streaming, sound, polished joystick ও collision physics এখনো যোগ করা হয়নি। Mode toggle এখন মূলত prototype toggle; পূর্ণ survival rules নয়।

## Online APK build (ফোন দিয়েই)
1. GitHub-এ নতুন repository তৈরি করো।
2. এই ZIP extract করে সব ফাইল repository-তে upload করো। `.github/workflows/android-apk.yml` ফাইলটিও upload হতে হবে।
3. Repository-এর **Actions** tab খোলো।
4. `Build MX CRAFT APK` workflow বেছে **Run workflow** চাপো।
5. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `MX-CRAFT-debug-apk` ZIP ডাউনলোড করো।
6. ZIP extract করলে `android-debug.apk` পাবে। Android-এ ইনস্টল করার সময় Android-এর app-install permission চাইতে পারে।

## PC / Android Studio দিয়ে build
- JDK 17
- Android SDK Platform 35
- Gradle 8.7
- Command: `gradle :android:assembleDebug`

## Package
`com.mxcraft.game`

## Controls
- স্ক্রিনের ডান পাশে drag: camera look
- নিচের বাম অংশে tap/hold: basic forward/left movement
- ডান দিকের উপরের `[MODE]`: Creative/Survival toggle
- ডান দিকের নিচে `[BREAK]` / `[PLACE]`: block action
- Keyboard (যদি থাকে): WASD, Space, M, B, P

> এটি প্রাথমিক starter code। বিভিন্ন Android device-এ performance ও touch controls আরও পরীক্ষা/উন্নত করতে হবে।
