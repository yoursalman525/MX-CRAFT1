package com.mxcraft.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.Ray;
import com.badlogic.gdx.utils.Array;
import java.util.Iterator;
import java.util.Random;

/**
 * MX CRAFT - small 3D voxel sandbox prototype.
 * Touch: drag right side to look, use bottom-left pad to move.
 * Tap BREAK / PLACE to interact with the block in front of the camera.
 */
public class MXCraftGame extends ApplicationAdapter implements InputProcessor {
    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private Environment environment;
    private SpriteBatch hudBatch;
    private BitmapFont font;
    private ModelBuilder modelBuilder;

    private Model grassModel, dirtModel, stoneModel, woodModel, leavesModel, sandModel;
    private final Array<Block> blocks = new Array<>();
    private final Vector3 playerPosition = new Vector3(0, 3, 7);
    private float yaw = 0f;
    private float pitch = -12f;
    private boolean creative = true;
    private boolean forward, backward, left, right;
    private boolean lookDragging;
    private int lastX, lastY;
    private String message = "Welcome to MX CRAFT!";
    private float messageTimer = 4f;

    private static final float BLOCK = 1f;
    private static final int WORLD_RADIUS = 9;

    private static class Block {
        int x, y, z;
        String type;
        ModelInstance instance;
        Block(int x, int y, int z, String type, Model model) {
            this.x=x; this.y=y; this.z=z; this.type=type;
            instance = new ModelInstance(model, x, y, z);
        }
    }

    @Override
    public void create() {
        modelBatch = new ModelBatch();
        hudBatch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(1.15f);
        modelBuilder = new ModelBuilder();

        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.72f, 0.72f, 0.72f, 1f));
        environment.add(new DirectionalLight().set(0.9f, 0.9f, 0.85f, -1f, -0.8f, -0.3f));

        grassModel = makeBlock(new Color(0.22f, 0.62f, 0.20f, 1f));
        dirtModel = makeBlock(new Color(0.48f, 0.29f, 0.14f, 1f));
        stoneModel = makeBlock(new Color(0.48f, 0.50f, 0.53f, 1f));
        woodModel = makeBlock(new Color(0.48f, 0.30f, 0.13f, 1f));
        leavesModel = makeBlock(new Color(0.12f, 0.43f, 0.16f, 1f));
        sandModel = makeBlock(new Color(0.82f, 0.74f, 0.48f, 1f));

        generateWorld();
        camera = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(playerPosition);
        updateCameraDirection();
        camera.near = 0.1f;
        camera.far = 100f;
        camera.update();

        Gdx.input.setInputProcessor(this);
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
    }

    private Model makeBlock(Color color) {
        Material material = new Material(ColorAttribute.createDiffuse(color));
        return modelBuilder.createBox(BLOCK, BLOCK, BLOCK, material,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
    }

    private void generateWorld() {
        Random random = new Random(24);
        for (int x=-WORLD_RADIUS; x<=WORLD_RADIUS; x++) {
            for (int z=-WORLD_RADIUS; z<=WORLD_RADIUS; z++) {
                int height = (int)(Math.sin(x * 0.42) * 1.2 + Math.cos(z * 0.37) * 1.0);
                for (int y=-2; y<=height; y++) {
                    String type = y == height ? "grass" : (y >= height-2 ? "dirt" : "stone");
                    addBlock(x, y, z, type);
                }
                if (random.nextFloat() < 0.035f && Math.abs(x) > 2 && Math.abs(z) > 2) {
                    int trunk = height + 1;
                    for (int t=0; t<3; t++) addBlock(x, trunk+t, z, "wood");
                    for (int lx=-2; lx<=2; lx++) for (int lz=-2; lz<=2; lz++)
                        for (int ly=2; ly<=4; ly++)
                            if (Math.abs(lx)+Math.abs(lz)+(ly==4?1:0) < 5 && !(lx==0 && lz==0 && ly<4))
                                addBlock(x+lx, trunk+ly-1, z+lz, "leaves");
                }
            }
        }
        // Small sandy patch
        for (int x=-2; x<=2; x++) for (int z=-2; z<=2; z++) {
            Block top = findBlock(x, 0, z);
            if (top != null) {
                removeAt(x, top.y, z);
                addBlock(x, top.y, z, "sand");
            }
        }
    }

    private void addBlock(int x, int y, int z, String type) {
        Model model = modelFor(type);
        if (model != null && findBlock(x,y,z) == null) blocks.add(new Block(x,y,z,type,model));
    }

    private Model modelFor(String type) {
        switch(type) {
            case "grass": return grassModel;
            case "dirt": return dirtModel;
            case "stone": return stoneModel;
            case "wood": return woodModel;
            case "leaves": return leavesModel;
            case "sand": return sandModel;
            default: return stoneModel;
        }
    }

    private Block findBlock(int x, int y, int z) {
        for (Block b : blocks) if (b.x==x && b.y==y && b.z==z) return b;
        return null;
    }

    private void removeAt(int x, int y, int z) {
        for (Iterator<Block> it=blocks.iterator(); it.hasNext();) {
            Block b=it.next();
            if (b.x==x && b.y==y && b.z==z) { it.remove(); return; }
        }
    }

    private void updateCameraDirection() {
        float yr = (float)Math.toRadians(yaw);
        float pr = (float)Math.toRadians(pitch);
        Vector3 direction = new Vector3(
            (float)(Math.sin(yr)*Math.cos(pr)),
            (float)Math.sin(pr),
            (float)(-Math.cos(yr)*Math.cos(pr))
        ).nor();
        camera.direction.set(direction);
        camera.up.set(Vector3.Y);
    }

    @Override
    public void render() {
        float delta = Math.min(Gdx.graphics.getDeltaTime(), 0.05f);
        updatePlayer(delta);
        camera.position.set(playerPosition);
        updateCameraDirection();
        camera.viewportWidth = Gdx.graphics.getWidth();
        camera.viewportHeight = Gdx.graphics.getHeight();
        camera.update();

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(0.48f, 0.72f, 0.94f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);

        modelBatch.begin(camera);
        for (Block b : blocks) modelBatch.render(b.instance, environment);
        modelBatch.end();

        drawHud(delta);
    }

    private void updatePlayer(float delta) {
        float speed = creative ? 5.0f : 3.0f;
        Vector3 forwardVec = new Vector3(camera.direction.x, 0, camera.direction.z).nor();
        Vector3 rightVec = new Vector3(forwardVec).crs(Vector3.Y).nor();
        if (forward) playerPosition.mulAdd(forwardVec, speed*delta);
        if (backward) playerPosition.mulAdd(forwardVec, -speed*delta);
        if (left) playerPosition.mulAdd(rightVec, -speed*delta);
        if (right) playerPosition.mulAdd(rightVec, speed*delta);
        // Keep the prototype player above the terrain.
        playerPosition.y = Math.max(1.7f, playerPosition.y);
    }

    private void drawHud(float delta) {
        hudBatch.begin();
        font.setColor(Color.WHITE);
        font.draw(hudBatch, "MX CRAFT", 18, Gdx.graphics.getHeight()-18);
        font.draw(hudBatch, creative ? "MODE: CREATIVE" : "MODE: SURVIVAL", 18, Gdx.graphics.getHeight()-44);
        font.draw(hudBatch, "Blocks: " + blocks.size, 18, Gdx.graphics.getHeight()-68);
        font.draw(hudBatch, "Drag right side: LOOK", 18, 28);
        font.draw(hudBatch, "Move: bottom-left zones", 18, 50);

        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        font.draw(hudBatch, "[ MODE ]", w-120, h-22);
        font.draw(hudBatch, "[ BREAK ]", w-130, 90);
        font.draw(hudBatch, "[ PLACE ]", w-130, 52);
        if (messageTimer > 0) {
            messageTimer -= delta;
            font.draw(hudBatch, message, w*0.36f, h-25);
        }
        hudBatch.end();
    }

    private void showMessage(String text) {
        message=text;
        messageTimer=2.2f;
    }

    private Block getTargetBlock() {
        Ray ray = camera.getPickRay(Gdx.graphics.getWidth()/2f, Gdx.graphics.getHeight()/2f);
        Block best=null;
        float bestDist=5.5f;
        Vector3 center = new Vector3();
        for (Block b : blocks) {
            center.set(b.x+0.5f,b.y+0.5f,b.z+0.5f);
            Vector3 to = new Vector3(center).sub(ray.origin);
            float along = to.dot(ray.direction);
            if (along < 0 || along > bestDist) continue;
            Vector3 closest = new Vector3(ray.direction).scl(along).add(ray.origin);
            if (closest.dst(center) < 0.9f) { best=b; bestDist=along; }
        }
        return best;
    }

    private void breakBlock() {
        Block target=getTargetBlock();
        if (target==null) { showMessage("No block in range"); return; }
        removeAt(target.x,target.y,target.z);
        showMessage("Block broken");
    }

    private void placeBlock() {
        Block target=getTargetBlock();
        if (target==null) { showMessage("Look at a block first"); return; }
        Vector3 dir = new Vector3(camera.direction).nor();
        int nx=target.x + (Math.abs(dir.x)>Math.abs(dir.y) && Math.abs(dir.x)>Math.abs(dir.z) ? (dir.x>0? -1:1) : 0);
        int ny=target.y + (Math.abs(dir.y)>Math.abs(dir.x) && Math.abs(dir.y)>Math.abs(dir.z) ? (dir.y>0? -1:1) : 0);
        int nz=target.z + (Math.abs(dir.z)>Math.abs(dir.x) && Math.abs(dir.z)>Math.abs(dir.y) ? (dir.z>0? -1:1) : 0);
        if (findBlock(nx,ny,nz)==null) {
            addBlock(nx,ny,nz,"grass");
            showMessage("Block placed");
        } else showMessage("Space is occupied");
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        lastX=screenX; lastY=screenY;
        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        float y=h-screenY;
        if (screenX>w-155 && y>h-75) {
            creative=!creative;
            showMessage(creative ? "Creative mode" : "Survival mode");
            return true;
        }
        if (screenX>w-155 && y<115) {
            if (y<70) placeBlock(); else breakBlock();
            return true;
        }
        if (screenX<w*0.38f && y<h*0.42f) {
            // Four directional touch regions on the lower-left side.
            if (screenX<w*0.19f) left=true; else forward=true;
            return true;
        }
        lookDragging=true;
        return true;
    }

    @Override
    public boolean touchUp(int x,int y,int pointer,int button) {
        forward=backward=left=right=false;
        lookDragging=false;
        return true;
    }

    @Override
    public boolean touchDragged(int x,int y,int pointer) {
        if (lookDragging) {
            float dx=x-lastX, dy=y-lastY;
            yaw -= dx*0.35f;
            pitch += dy*0.25f;
            pitch=Math.max(-80,Math.min(80,pitch));
        }
        lastX=x; lastY=y;
        return true;
    }

    @Override public boolean keyDown(int keycode) {
        if (keycode==Input.Keys.W || keycode==Input.Keys.UP) forward=true;
        if (keycode==Input.Keys.S || keycode==Input.Keys.DOWN) backward=true;
        if (keycode==Input.Keys.A || keycode==Input.Keys.LEFT) left=true;
        if (keycode==Input.Keys.D || keycode==Input.Keys.RIGHT) right=true;
        if (keycode==Input.Keys.SPACE) playerPosition.y+=0.8f;
        if (keycode==Input.Keys.M) creative=!creative;
        if (keycode==Input.Keys.B) breakBlock();
        if (keycode==Input.Keys.P) placeBlock();
        return true;
    }
    @Override public boolean keyUp(int keycode) {
        if (keycode==Input.Keys.W || keycode==Input.Keys.UP) forward=false;
        if (keycode==Input.Keys.S || keycode==Input.Keys.DOWN) backward=false;
        if (keycode==Input.Keys.A || keycode==Input.Keys.LEFT) left=false;
        if (keycode==Input.Keys.D || keycode==Input.Keys.RIGHT) right=false;
        return true;
    }
    @Override public boolean keyTyped(char c){return false;}
    @Override public boolean mouseMoved(int x,int y){return false;}
    @Override public boolean scrolled(float amountX,float amountY){return false;}

    @Override
    public void resize(int width,int height) {
        if (camera!=null) { camera.viewportWidth=width; camera.viewportHeight=height; camera.update(); }
    }

    @Override
    public void dispose() {
        if (modelBatch!=null) modelBatch.dispose();
        if (hudBatch!=null) hudBatch.dispose();
        if (font!=null) font.dispose();
        if (grassModel!=null) grassModel.dispose();
        if (dirtModel!=null) dirtModel.dispose();
        if (stoneModel!=null) stoneModel.dispose();
        if (woodModel!=null) woodModel.dispose();
        if (leavesModel!=null) leavesModel.dispose();
        if (sandModel!=null) sandModel.dispose();
    }
}
